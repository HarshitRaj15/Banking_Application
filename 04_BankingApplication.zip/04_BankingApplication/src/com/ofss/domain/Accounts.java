package com.ofss.domain;

public class Accounts {
	private int accountNumber;
	private String name;
	private double balance;
	private static int accountNumberCounter=100;
	
	public Accounts() {
		System.out.println("Default Constructor of Account");
		accountNumberCounter++;
		accountNumber=accountNumberCounter;
		
	}
	
	public Accounts(String name, double balance) {
		System.out.println("Overloaded Constructor of Accounts");
		this.name = name;
		this.balance = balance;
		accountNumberCounter++;
		accountNumber=accountNumberCounter;
	}
	
	public Accounts(int accountNumber, String name, double balance) {
		System.out.println("Overloaded Constructor of Accounts");
		this.accountNumber = accountNumber;
		this.name = name;
		this.balance = balance;
		accountNumberCounter++;
		accountNumber=accountNumberCounter;
	}



	public boolean withdraw(double amount) {
		if(amount > 0 && amount <= balance) {
			balance  = balance-amount;
			return true;
		}
		return false;
	}
	
	public boolean deposit(double amount) {
		if(amount > 0) {
			balance  = balance+amount;
			return true;
		}
		return false;
	}
	
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}
	
	public int getAccountNumber() {
		return accountNumber;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String getName() {
		return name;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	public double getBalance() {
		return balance;
	}
}
