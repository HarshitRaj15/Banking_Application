package com.ofss.main;

import com.ofss.domain.Accounts;

public class BankingMain {
	public static void main(String[] args) {
		System.out.println("Main Start");
		Accounts accounts = new Accounts();
		accounts.setAccountNumber(101);
		accounts.setName("Harshit");
		accounts.setBalance(2000);
		
		Accounts accounts2 = new Accounts();
		accounts2.setAccountNumber(102);
		accounts2.setName("Manish");
		accounts2.setBalance(2000);

		System.out.println("Account Number"+" " +accounts.getAccountNumber());;
		System.out.println("Name"+" "+accounts.getName());
		System.out.println("Balance"+" "+accounts.getBalance());
		
		System.out.println("Account Number"+" " +accounts2.getAccountNumber());;
		System.out.println("Name"+" "+accounts2.getName());
		System.out.println("Balance"+" "+accounts2.getBalance());
		
		System.out.println("Main End");
	}
}
