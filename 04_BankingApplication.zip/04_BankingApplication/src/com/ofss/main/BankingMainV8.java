package com.ofss.main;

import com.ofss.domain.Accounts;

public class BankingMainV8 {
	public static void main(String[] args) {
		Accounts account1 = new Accounts("Test 1",1000);
		Accounts account2 = new Accounts("Test 2",1000);
		Accounts account3 = new Accounts("Test 3",1000);
		
		System.out.println("Account 1");
		System.out.println(account1.getAccountNumber());
		
		System.out.println();
		
		System.out.println("Account 2");
		System.out.println(account2.getAccountNumber());
		
		System.out.println();
		
		System.out.println("Account 3");
		System.out.println(account3.getAccountNumber());
		
	}
}
