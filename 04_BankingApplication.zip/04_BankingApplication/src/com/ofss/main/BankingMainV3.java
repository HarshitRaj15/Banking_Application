package com.ofss.main;

import java.util.Scanner;

import com.ofss.domain.Accounts;
import com.ofss.domain.Savings;

public class BankingMainV3 {
	public static void main(String[] args) {
		int accountNumber;
		String name;
		double balance;
		int choice;
		double amount;
		boolean result;
		String continuechoice;
		boolean isOfTypeSalary;
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Enter account opening details");
		System.out.println("Enter account number");
		accountNumber = scanner.nextInt();
		System.out.println("Enter Name");
		name=scanner.next();
		System.out.println("Enter Balance");
		balance=scanner.nextDouble();
		System.out.println("Do You Want to open Salary Account(true or false)");
		isOfTypeSalary=scanner.nextBoolean();
		

		
		//Accounts account = new Accounts();
		//account.setAccountNumber(accountNumber);
		//.setName(name);
		//account.setBalance(balance);
		//Accounts account = new Accounts(accountNumber,name,balance);
		Savings account = new Savings(accountNumber,name,balance,isOfTypeSalary);
		
		do {
		System.out.println("Account open  successfully!");
		System.out.println("Menu");
		System.out.println("1. Withdraw");
		System.out.println("2. Deposit");
		System.out.println("3. Balance");
		System.out.println("Enter your choice");
		choice = scanner.nextInt();
		switch (choice) {
		case 1:
			System.out.println("You have selected withdraw");
			System.out.println("Enter amount to withdraw");
			amount = scanner.nextDouble();
			result=account.withdraw(amount);
			if(result == true)
				System.out.println("Transaction Successfull!");
			else {
				System.out.println("Transaction Failed!!");
				System.out.println("Balance ::" + account.getBalance());
			}
		break;
		case 2:
			System.out.println("You have selected withdraw");
			System.out.println("Enter amount to withdraw");
			amount = scanner.nextDouble();
			result=account.deposit(amount);
			if(result == true)
				System.out.println("Transaction Successfull!");
			else {
				System.out.println("Transaction Failed!!");
				System.out.println("Balance ::" + account.getBalance());
			}
		break;
		case 3:
			System.out.println("Your balance:" + account.getBalance());
		break;
		default:
			System.out.println("Invalid Choice");
		break;
		}
		System.out.println("Do you want to continue? Yes - No");
		continuechoice = scanner.next();
	}while(continuechoice.equals("Yes"));
	
	}
}
